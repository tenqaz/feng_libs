import telnetlib


def getUidListByAppid(appid, db):
    """
        通过appid 获取UidList
    """
    db.select('txz_account')
    uid_df = db.read_dataframe_from_sql(
        "select uid from device_base where txz_app_id = '%s'" % appid,
        use_file=True
    )

    uid_list = uid_df["uid"].tolist()

    return uid_list


def GetTimeAndAccessToken():
    """
        获取token
    """
    host = "m-bp1e17713aa9d764721.memcache.rds.aliyuncs.com"
    tn = telnetlib.Telnet(host=host, port=11211)
    tn.write(bytes("get wxc46e72f242ab5a19_access_token\n", encoding='utf-8'))
    finish = 'END'
    result = tn.read_until(bytes(finish, encoding='utf-8'))
    tn.close()
    result_list = str(result).split("\\r\\n")
    time_access_token = result_list[1].split(",")
    start_time = time_access_token[0]
    access_token = time_access_token[1]
    return start_time, access_token


def unzip_chrono_file(
    startTime, endTime,
    source_path="/txz_user_action_data/txz/logicError",
    aim_path="/home/jim/monitor_data",
):
    '''
    将流水文件复制到自定义目录，再解压取得.le文件
    :param
            source_path: 源数据文件路径
            aim_path: 目标路径
            startTime: 开始时间
            endTime: 结束时间 +1

            return : file_list           *包含三个文件名的列表
    '''

    # 复制文件到自己的目录下
    fileList = [source_path+"/" +
                file.format()+".7z" for file in Moment.range(startTime, endTime)]
    files = " ".join(fileList)
    cmd_str = '''cp {files} {aim_path}'''.format(**{
        'files': files,
        'aim_path': aim_path,
    })
    os.system(cmd_str)

    # 解压成3个文件
    for file in Moment.range(startTime, endTime):
        _file = file.format()+".7z"
        cmd_unzip_str = f"7za x {aim_path}/{_file} -o{aim_path}"
        os.system(cmd_unzip_str)
