"""
    author: jim
    date: 2018-11-19

    同行者关于场景的过滤。 该类依赖于txz_libs库

"""

from txz_libs.proto.py.report_manager_pb2 import UAT_VOICE, UAT_VOICE_REPEAT

scene_list = {
    'unknow': 'scene_unknow', '唤醒': 'scene_wakeup',
    '设置唤醒词': 'scene_set_wakeup_keywords', '执行命令': 'scene_command',
    'app': 'scene_app', '打电话': 'scene_call', '导航相关': 'scene_nav',
    'poi': 'scene_poi', '音乐相关': 'scene_music', '天气相关': 'scene_weather',
    '股票相关': 'scene_stock', '相关位置': 'scene_location',
    '交通相关': 'scene_traffic', '限行相关': 'scene_limit',
    '不支持操作': 'scene_unsupport', '没有说话': 'scene_empty',
    '微信相关': 'scene_wechat', '查询相关': 'scene_query',
    '系统相关': 'scene_system', '上次会话更改': 'scene_fix',
    'core_相关': 'scene_txz', '电台相关': 'scene_radio',
    '闲聊相关': 'scene_chat'
}


def scene_unknow(df):
    """无法识别"""
    return df[(df.json.str.contains('"scene":"unknown"') |
               df.json.str.contains('"r":"nul"') |
               df.json.str.contains('"r":"nul"')) &
              ~df.json.str.contains('"answer"')
              ]


def scene_wakeup(df):
    """唤醒"""
    return df[df.json.str.contains('"scene":"wakeup"') |
              df.json.str.contains('"r":"wakeup"')]


def scene_set_wakeup_keywords(df):
    """设置唤醒词"""
    return df[df.json.str.contains('"scene":"set_user_wakeup_keywords"')]


def scene_command(df):
    """执行命令"""
    return df[df.json.str.contains('"scene":"command"') |
              df.json.str.contains('"cmd"')]


def scene_app(df):
    """应用相关"""
    return df[df.json.str.contains('"scene":"app"') |
              df.json.str.contains('"r":"app"')]


def scene_call(df):
    """电话场景"""
    return df[df.json.str.contains('"scene":"call"') |
              df.json.str.contains('"r":"call"')]


def scene_nav(df):
    """导航相关"""
    return df[df.json.str.contains('"scene":"nav"') |
              df.json.str.contains('"r":"nav"')]


def scene_poi(df):
    """poi相关"""
    return df[df.json.str.contains('"scene":"poi"')]


def scene_music(df):
    """音乐相关"""
    return df[df.json.str.contains('"scene":"music"') |
              df.json.str.contains('"scene":"audio"') |
              df.json.str.contains('"r":"msc"')]


def scene_weather(df):
    """天气相关"""
    return df[df.json.str.contains('"scene":"weather"')]


def scene_stock(df):
    """
    股票相关
    """
    return df[df.json.str.contains('"scene":"stock"')]


def scene_location(df):
    """位置相关"""
    return df[df.json.str.contains('"scene":"location"')]


def scene_traffic(df):
    """
    路况
    """
    return df[df.json.str.contains('"scene":"traffic"')]


def scene_limit(df):
    """限行"""
    return df[df.json.str.contains('"scene":"limit_number"')]


def scene_unsupport(df):
    """不支持操作"""
    return df[df.json.str.contains('"scene":"unsupport"')]


def scene_empty(df):
    """没有说话"""
    return df[df.json.str.contains('"scene":"empty"') |
              df.json.str.contains('"r":"empty"')]


def scene_wechat(df):
    """微信场景"""
    return df[df.json.str.contains('"scene":"wechat"')]


def scene_query(df):
    """查询相关"""
    return df[df.json.str.contains('"scene":"query"')]


def scene_system(df):
    """系统指令"""
    return df[df.json.str.contains('"scene":"system"') |
              df.json.str.contains('"r":"cmd"')]


def scene_fix(df):
    """对上次会话进行更改"""
    return df[df.json.str.contains('"scene":"fix"')]


def scene_txz(df):
    """core相关"""
    return df[df.json.str.contains('"scene":"txz"')]


def scene_radio(df):
    """电台相关"""
    return df[df.json.str.contains('"scene":"radio"')]


def scene_chat(df):
    """闲聊场景"""
    return df[df.json.str.contains('"r":"cmu"') |
              (df.json.str.contains('"scene":"unknown"') &
               df.json.str.contains('"answer"'))]


def voice_search_df(df):
    """
        过滤voice(语音)
    """
    return df[(df.uat.isin([UAT_VOICE, UAT_VOICE_REPEAT]))]