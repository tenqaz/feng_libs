'''
    author: jim
    date: 2018-09-07

    操作excel的工具类

    TODO(2018-09-07): 目前还不完善，只有简单读功能，后续如有需要加上写功能
'''
import xlrd


class ExcelUtils:

    __slots__ = ['sheet_names', 'cur_sheet_name', 'cur_sheet', 'workbook']

    def __init__(self):
        pass

    def load(self, file):
        '''
        
        file: 文件路径
        function: 加载excel文件

        '''
        self.workbook = xlrd.open_workbook(file)
        self.sheet_names = self.workbook.sheet_names()
        self.cur_sheet_name = self.sheet_names[0]
        self.cur_sheet = self.workbook.sheet_by_index(0)

    def select(self, sheet_name_or_index):
        '''

            sheet_name_or_index: sheet的名字或索引
            funtion: 选择sheet

        '''
        if isinstance(sheet_name_or_index, int):
            self.cur_sheet_name = sheet_names[sheet_name_or_index]
            self.cur_sheet = self.workbook.sheet_by_index(sheet_name_or_index)
        elif isinstance(sheet_name_or_index, str):
            self.cur_sheet_name = sheet_name_or_index
            self.cur_sheet = self.workbook.sheet_by_name(sheet_name)

    def get_row_values(self, row):
        '''
            row: 行数
            return: list
            function: 获取行
        '''
        return self.cur_sheet.row_values(row)

    def get_column_values(self, col):
        '''
            col: 列数
            function: 获取列
        '''
        return self.cur_sheet.col_values(col)

if __name__ == '__main__':
    eu = ExcelUtils()
    eu.load('济南和云镜CM02采购明细.xlsx')
    print(eu.sheet_names)

    print(eu.get_row_values(0))
    print(eu.get_column_values(0))